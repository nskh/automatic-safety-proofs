# Automated Geometric Safety Proofs

A project by @nskh, @jeannin, and @elanortang
